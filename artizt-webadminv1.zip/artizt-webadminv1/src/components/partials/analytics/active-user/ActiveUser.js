import React from "react";
import { Icon, TooltipComponent } from "../../../Component";
import { ActiveUserBarChart } from "../../charts/analytics/AnalyticsCharts";

const ActiveUser = () => {
  return (
    <React.Fragment>
      <div className="card-title-group align-start pb-3 g-2">
        <div className="card-title card-title-sm">
          <h6 className="title">Active Users</h6>
          <p>Overall Analytics active users</p>
        </div>
        <div className="card-tools">
          <TooltipComponent
            iconClass="card-hint"
            icon="help"
            direction="left"
            id="Tooltip-users"
            text="Users of this month"
          ></TooltipComponent>
        </div>
      </div>
      <div className="analytic-au">
        <div className="analytic-data-group analytic-au-group g-3">
          <div className="analytic-data analytic-au-data">
            <div className="title">Monthly</div>
            <div className="amount">928</div>
           
          </div>
          <div className="analytic-data analytic-au-data">
            <div className="title">Weekly</div>
            <div className="amount">269</div>
           
          </div>
          <div className="analytic-data analytic-au-data">
            <div className="title">Daily (Avg)</div>
            <div className="amount">14</div>
            
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};
export default ActiveUser;
