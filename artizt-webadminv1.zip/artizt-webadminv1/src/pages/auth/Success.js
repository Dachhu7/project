import React from "react";
import Logo from "../../images/logoart.png";
import LogoDark from "../../images/logoart.png";
import Head from "../../layout/head/Head";
import AuthFooter from "./AuthFooter";
import { Block, BlockContent, BlockDes, BlockHead, BlockTitle, PreviewCard } from "../../components/Component";
import { Link } from "react-router-dom";
import { Button } from "../../components/Component";

const Success = () => {
  return (
    <>
      <Head title="Success" />
      <Block className="nk-block-middle nk-auth-body  wide-xs">
        <PreviewCard className="card-bordered" bodyClass="card-inner-lg">
          <BlockHead>
            <BlockContent>
              <div className="brand-logo pb-4  pt-4 text-center">
                <Link to={process.env.PUBLIC_URL + "/"} className="logo-link">
                  <img className="logo-light logo-img logo-img-lgg" src={Logo} alt="logo" />
                  <img className="logo-dark logo-img logo-img-lgg" src={LogoDark} alt="logo-dark" />
                </Link>
              </div>
              <BlockHead>
                <BlockContent className="text-center">
                  <BlockTitle tag="h4">Thank you for submitting form</BlockTitle>
                  <BlockDes className="text-success">
                    <p>You can now sign in with your new password</p>
                    <Link to={`${process.env.PUBLIC_URL}/auth-login`}>
                      <Button color="primary" size="lg">
                        Login Now
                      </Button>
                    </Link>
                  </BlockDes>
                </BlockContent>
              </BlockHead>
            </BlockContent>
          </BlockHead>
        </PreviewCard>
      </Block>
    </>
  );
};
export default Success;
