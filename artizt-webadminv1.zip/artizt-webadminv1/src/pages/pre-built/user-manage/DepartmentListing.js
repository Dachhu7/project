import React, { useContext, useState } from "react";
import Content from "../../../layout/content/Content";
import Head from "../../../layout/head/Head";
import {
  Block,
  BlockBetween,
  BlockDes,
  BlockHead,
  BlockHeadContent,
  BlockTitle,
  Icon,
  PreviewCard,
  ReactDataTable,
  Button,
} from "../../../components/Component";

import { dataTabledepart, datadepart } from "../../components/table/TableData";

const Departmentslisting = () => {
  
  return (
    <React.Fragment>
      <Head title="Basic Tables" />
      <Content>
        <Block size="sm">
        <BlockHead size="sm">
          <BlockBetween>
            <BlockHeadContent>
              <BlockTitle page>Admin Controllers</BlockTitle>
              <BlockDes className="text-soft">
                <p>You have total 10 users.</p>
              </BlockDes>
            </BlockHeadContent>
            <BlockHeadContent>
              <div className="toggle-wrap nk-block-tools-toggle">
               
              <ul className="nk-block-tools g-3">
                    <li className="nk-block-tools-opt">
                      <Button color="primary" className="btn-icon" onClick={() => ({ add: true })}>
                        <Icon name="plus"></Icon>
                      </Button>
                    </li>
                  </ul>
              </div>
            </BlockHeadContent>
          </BlockBetween>
        </BlockHead>
          <PreviewCard>
            <ReactDataTable
              data={datadepart}
              columns={dataTabledepart}
              pagination
              className="nk-tb-list"
              selectableRows
            />
          </PreviewCard>
        </Block>
      </Content>
    </React.Fragment>
  );
};
export default Departmentslisting;
