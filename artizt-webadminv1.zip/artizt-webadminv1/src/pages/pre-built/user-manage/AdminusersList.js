import React, { useContext, useState } from "react";
import Content from "../../../layout/content/Content";
import Head from "../../../layout/head/Head";
import { DropdownMenu, DropdownToggle, UncontrolledDropdown, DropdownItem } from "reactstrap";
import {
  Block,
  BlockBetween,
  BlockDes,
  BlockHead,
  BlockHeadContent,
  BlockTitle,
  Icon,
  Row,
  Col,
  UserAvatar,
  Button,
  PreviewAltCard,
} from "../../../components/Component";
import { Link } from "react-router-dom";
import { userData } from "./UserData";
import { findUpper } from "../../../utils/Utils";
import { UserContext } from "./UserContext";
import CardFormModal from "./CardFormModal";

const Adminuserlist = () => {
  const { contextData } = useContext(UserContext);
  const [data, setData] = contextData;

  const [editId, setEditedId] = useState();
  const [smOption, setSmOption] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    designation: "",
    projects: "",
    performed: "",
    tasks: "",
  });
  const [editFormData, setEditFormData] = useState({
    name: "",
    designation: "",
    projects: "",
    performed: "",
    tasks: "",
  });
  const [modal, setModal] = useState({
    add: false,
    edit: false,
  });

  // function to reset the form
  const resetForm = () => {
    setFormData({
      name: "",
      designation: "",
      projects: "",
      performed: "",
      tasks: "",
    });
  };

  // submit function to add a new item
  const onFormSubmit = (formData) => {
    const { name, designation, projects, performed, tasks } = formData;
    let submittedData = {
      id: data.length + 1,
      avatarBg: "success",
      name: name,
      status: "Active",
      designation: designation,
      projects: projects,
      performed: performed,
      tasks: tasks,
    };
    setData([submittedData, ...data]);
    resetForm();
    setModal({ add: false });
  };

  // submit function to update a new item
  const onEditSubmit = (formData) => {
    const { name, designation, projects, performed, tasks } = formData;
    let submittedData;
    let newitems = data;
    newitems.forEach((item) => {
      if (item.id === editId) {
        submittedData = {
          ...item,
          id: item.id,
          avatarBg: item.avatarBg,
          name: name,
          status: "Active",
          email: item.email,
          designation: designation,
          projects: projects,
          performed: performed,
          tasks: tasks,
        };
      }
    });
    let index = newitems.findIndex((item) => item.id === editId);
    newitems[index] = submittedData;
    setData(newitems);
    setModal({ edit: false });
  };

  const closeModal = () => {
    setModal({ add: false });
    resetForm();
  };

  const closeEditModal = () => {
    setModal({ edit: false });
    resetForm();
  };

  // function that loads the want to editted data
  const onEditClick = (id) => {
    data.forEach((item) => {
      if (item.id === id) {
        setEditFormData({
          name: item.name,
          designation: item.designation,
          projects: item.projects,
          performed: item.performed,
          tasks: item.tasks,
        });
        setModal({ edit: true, add: false });
        setEditedId(id);
      }
    });
  };

  // function to change to suspend property for an item
  const suspendUser = (id) => {
    let newData = data;
    let index = newData.findIndex((item) => item.id === id);
    newData[index].status = "Suspend";
    setData([...newData]);
  };

  return (
    <React.Fragment>
      <Head title="User Contact - Card"></Head>
      <Content>
        <BlockHead size="sm">
          <BlockBetween>
            <BlockHeadContent>
              <BlockTitle page>Admin Controllers</BlockTitle>
              <BlockDes className="text-soft">
                <p>You have total 10 users.</p>
              </BlockDes>
            </BlockHeadContent>
            <BlockHeadContent>
              <div className="toggle-wrap nk-block-tools-toggle">
               
                <div className="toggle-expand-content" style={{ display: smOption ? "block" : "none" }}>
                  <ul className="nk-block-tools g-3">
                    <li className="nk-block-tools-opt">
                      <Button color="primary" className="btn-icon" onClick={() => setModal({ add: true })}>
                        <Icon name="plus"></Icon>
                      </Button>
                    </li>
                  </ul>
                </div>
              </div>
            </BlockHeadContent>
          </BlockBetween>
        </BlockHead>

        <Block>
          <Row className="g-gs">
            {data.slice(0, 4).map((item) => {
              return (
                <Col sm="6" lg="4" xxl="3" key={item.id}>
                  <PreviewAltCard>
                    <div className="team">
                      <div
                        className={`team-status ${
                          item.status === "Active"
                            ? "bg-success text-white"
                            : item.status === "Pending"
                            ? "bg-warning text-white"
                            : "bg-danger text-white"
                        } `}
                      >
                        <Icon
                          name={`${
                            item.status === "Active" ? "check-thick" : item.status === "Pending" ? "clock" : "na"
                          }`}
                        ></Icon>
                      </div>
                      <div className="team-options">
                        <UncontrolledDropdown>
                          <DropdownToggle tag="a" className="dropdown-toggle btn btn-icon btn-trigger">
                            <Icon name="more-h"></Icon>
                          </DropdownToggle>
                          <DropdownMenu end>
                            <ul className="link-list-opt no-bdr">
                              <li onClick={() => onEditClick(item.id)}>
                                <DropdownItem
                                  tag="a"
                                  href="#edit"
                                  onClick={(ev) => {
                                    ev.preventDefault();
                                  }}
                                >
                                  <Icon name="edit"></Icon>
                                  <span>Edit profile</span>
                                </DropdownItem>
                              </li>
                              <li onClick={() => onEditClick(item.id)}>
                                <DropdownItem
                                  tag="a"
                                  href="#edit"
                                  onClick={(ev) => {
                                    ev.preventDefault();
                                  }}
                                >
                                  <Icon name="change"></Icon>
                                  <span>Change Control</span>
                                </DropdownItem>
                              </li>
                              <li onClick={() => onEditClick(item.id)}>
                                <DropdownItem
                                  tag="a"
                                  href="#edit"
                                  onClick={(ev) => {
                                    ev.preventDefault();
                                  }}
                                >
                                  <Icon name="danger"></Icon>
                                  <span>Deactivate</span>
                                </DropdownItem>
                              </li>
                              <li onClick={() => onEditClick(item.id)}>
                                <DropdownItem
                                  tag="a"
                                  href="#edit"
                                  onClick={(ev) => {
                                    ev.preventDefault();
                                  }}
                                >
                                  <Icon name="delete"></Icon>
                                  <span>Delete</span>
                                </DropdownItem>
                              </li>
                            </ul>
                          </DropdownMenu>
                        </UncontrolledDropdown>
                      </div>
                      <div className="user-card user-card-s2">
                        <UserAvatar theme={item.avatarBg} className="md" text={findUpper(item.name)} image={item.image}>
                          <div className="status dot dot-lg dot-success"></div>
                        </UserAvatar>
                        <div className="user-info">
                          <h6>{item.name}</h6>
                          <span className="sub-text">{item.designation.split(" ")[0].toLowerCase()}</span>
                        </div>
                      </div>
                      <span class="tb-amount">
                        <td>
                        <p class="mb-0 ">Admin Permissions</p>
                          <div class="d-flex pt-1 gap-1 h-100 flex-wrap">
                            <span id="arts" class="badge bg-outline-dark">
                             Manage Users
                            </span>
                            <span class="badge bg-outline-dark">Library Collection</span>
                            <span class="badge bg-outline-dark">User Verification</span>
                            <span class="badge bg-outline-dark">Sales Invoice</span>
                            <span class="badge bg-outline-dark">General Settings</span>
                          </div>
                        </td>
                      </span>
                      <ul className="team-info">
                        <li>
                          <span>Contact :</span>
                          <span>{item.phone}</span>
                        </li>
                        <li>
                          <span>Email :</span>
                          <span>{item.email}</span>
                        </li>
                      </ul>
                    </div>
                  </PreviewAltCard>
                </Col>
              );
            })}
          </Row>
        </Block>

        

        <CardFormModal
          modal={modal.add}
          modalType="add"
          formData={formData}
          setFormData={setFormData}
          closeModal={closeModal}
          onSubmit={onFormSubmit}
        />
        <CardFormModal
          modal={modal.edit}
          modalType="edit"
          formData={editFormData}
          setFormData={setEditFormData}
          closeModal={closeEditModal}
          onSubmit={onEditSubmit}
        />
      </Content>
    </React.Fragment>
  );
};
export default Adminuserlist;
